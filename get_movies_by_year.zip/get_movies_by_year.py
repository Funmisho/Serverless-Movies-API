# Function that fetches movies relesed in a specific year

import boto3
import json

def lambda_handler(event, context):
    year = event['queryStringParameters']['year']
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Movies')

    # Query the table by year
    response = table.scan() #dynamodb scan for simple filters
    movies = [movie for movie in response.get('Items', []) if str(movie['releaseYear']) == year]
    
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(movies)
    }
