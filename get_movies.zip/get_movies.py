# Function that fetches all movies from DynamoDB and returns their
# details including the cover image URL from S3

import boto3
import json

def lambda_handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('Movies')

    # scan the table to fetch all items
    response = table.scan()
    movies = response.get('Items', [])

    # return the result
    return {
        "statusCode": 200,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(movies)
    }
